#!/bin/sh
datatype=$1

if [ $datatype == "TIO" ];then
   echo  "TIO"
else
   echo "other"
fi
